# AntibioticBench benchmark data

This directory contains the 12 genus-level CSV tables supplied with the AntibioticBench manuscript, *AntibioticBench: an evaluation framework for antimicrobial activity prediction and virtual screening*. The tables contain 269,072 rows in total. Each file is an unchanged copy of the corresponding CSV supplied in the original project data archive.

## Contents

| File | Rows | Columns |
| --- | ---: | ---: |
| `data/1_Staphylococcus_median_16_MolWt_50_1000_value_le_8192.csv` | 63,860 | 92 |
| `data/2_Escherichia_median_32_MolWt_50_1000_value_le_8192.csv` | 50,234 | 92 |
| `data/3_Pseudomonas_median_32_MolWt_50_1000_value_le_8192.csv` | 33,899 | 92 |
| `data/4_Bacillus_median_16_MolWt_50_1000_value_le_8192.csv` | 30,947 | 92 |
| `data/5_Enterococcus_median_8_MolWt_50_1000_value_le_8192.csv` | 19,115 | 92 |
| `data/6_Klebsiella_median_32_MolWt_50_1000_value_le_8192.csv` | 19,395 | 92 |
| `data/7_Streptococcus_median_4_MolWt_50_1000_value_le_8192.csv` | 15,892 | 92 |
| `data/8_Acinetobacter_median_16_MolWt_50_1000_value_le_8192.csv` | 10,254 | 92 |
| `data/10_Salmonella_median_32_MolWt_50_1000_value_le_8192.csv` | 6,587 | 92 |
| `data/11_Mycobacterium_median_8_MolWt_50_1000_value_le_8192.csv` | 7,443 | 92 |
| `data/14_Candida_median_32_MolWt_50_1000_value_le_8192.csv` | 7,333 | 92 |
| `data/15_Micrococcus_median_32_MolWt_50_1000_value_le_8192.csv` | 4,113 | 92 |

The distributed ZIP contains this README, the CSV files, and `SHA256SUMS`. The checksum file covers this README and the CSV files; after extraction, verify them with `sha256sum -c SHA256SUMS`.

## Data description

The manuscript describes genus-level minimum inhibitory concentration (MIC) records compiled from ChEMBL, PubChem, SPARK, CO-ADD, NPASS, and ChemDiv. Structures and activity values were curated and duplicate compound–genus measurements aggregated. Measurements may originate from different strains and assay conditions. Consult the manuscript for the curation methods and limitations.

The tables include `source`, `source_id`, `smiles`, `value`, and `genus`, as well as standardized structure fields, descriptors, activity labels, and quality annotations. Source labels are preserved as supplied, including `NAPSS`. The `source` field should not be assumed to record every source contributing to an aggregated measurement.

These tables are not precomputed train, validation, and test splits. Some columns summarize relationships across the original full table; in particular, nearest-neighbor indices and similarities should not be interpreted as positions or relationships within a filtered subset or an independently created split.

## Reuse and attribution

The data incorporate material from multiple third-party sources. Rights and reuse conditions for individual sources and aggregated records should be checked against the original providers; a license for the project code does not grant rights to third-party data. Cite the manuscript and relevant original data sources when using these data. Full manuscript citation details will be added when available.

## Contact

Questions: zhaisilong@outlook.com. Code repository: https://github.com/zhaisilong/AntibioticBench
